<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Holiday List</title>
        <link rel="stylesheet" href="department.css">
        <link rel="icon" href="simle.ico">
    </head>
    <body>
        
            
            <header class="header_style flex justify-centre">
                <h1><u>STUDENT TIMETABLE MANAGEMENT SYSTEM</u></h1>
            </header>
            <nav>   
                <div class="navbar shadow">
                    <div class="container flex justify-centre">
                        <a href="student.php" ><b>Dashboard</b></a>
                        <a href="studclasstt.php" ><b>View Class Time Table</b></a>
                        <a href="studexamtt.php"  ><b>View Exam Time Table</b></a>
                        <a href="studnotice.php" ><b>Notice</b></a>
                        <a href="studholiday.php" class="active"><b>Holiday</b></a>
                        <a href="studevent.php"><b>Events</b></a>
                        <a href="index.php"><b>Log out</b></a>
                    </div>
                </div>
            </nav>
<br>
<img src="holiday/Holiday List.jpg" alt="Holiday List" class="center" style="width:700px;height:600px; margin-left:300px;">
<img src="holiday/Holiday List1.jpg" alt="Holiday List" class="center" style="width:700px;height:850px; margin-left:300px;">

<br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <footer id="footer">
                <b>----Our Developers----</b>
                <br>
                <b>Anshu Gupta - Anusha Mandal - Archana Prakash</b>
            </footer>   


</body>
</html>
