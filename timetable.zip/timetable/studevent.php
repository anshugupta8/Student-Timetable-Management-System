<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Events</title>
        <link rel="stylesheet" href="department.css">
        <link rel="icon" href="simle.ico">
    </head>
    <body>
        
            
            <header class="header_style flex justify-centre">
                <h1><u>STUDENT TIMETABLE MANAGEMENT SYSTEM</u></h1>
            </header>
            <nav>   
                <div class="navbar shadow">
                    <div class="container flex justify-centre">
                        <a href="student.php" ><b>Dashboard</b></a>
                        <a href="studclasstt.php" ><b>View Class Time Table</b></a>
                        <a href="studexamtt.php"  ><b>View Exam Time Table</b></a>
                        <a href="studnotice.php" ><b>Notice</b></a>
                        <a href="studholiday.php" ><b>Holiday</b></a>
                        <a href="studevent.php" class="active" ><b>Events</b></a>
                        <a href="index.php"><b>Log out</b></a>
                    </div>
                </div>
            </nav>
<br>
<a href="https://www.ureckon.org">
<img src="events/ureckon.jpg" alt="Techfest"  style="width:1000px;height:600px; margin-left:180px;"></a>

<br>
<a href="https://www.ecstasia.org">
<img src="events/e.jpg" alt="Culturalfest"  style="width:600px;height:350px; margin-left:80px;"></a>
<a href="https://www.youtube.com/watch?v=4ciqYLzPKnI">
<img src="events/e1.jpeg" alt="Culturalfest"  style="width:600px;height:350px; "></a>
<br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <footer id="footer">
                <b>----Our Developers----</b>
                <br>
                <b>Anshu Gupta - Anusha Mandal - Archana Prakash</b>
            </footer>   
</body>
</html>
