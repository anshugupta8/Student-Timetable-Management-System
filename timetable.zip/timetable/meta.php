<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<style>
body
{
color: white;
font-family: "Times New Roman", Times, serif;
background-image: linear-gradient(red,orange,yellow,rgb(4, 218, 4),blue,rgb(122, 7, 204),rgb(250, 6, 250));
background-image: url("aaaa.jpg");
background-repeat: no-repeat;
background-size: cover;
}
li
{
padding :10px;
background-color:red;
display:inline-block;

}
.header-text
{
margin-top:10px;
background-color:black;
width:80%;
border:4px  rgb(255, 0, 170) solid;
border-radius:15px;
border-style:groove;
text-align:center;
margin-left:150px;
}
.container
{
    width: 100%;
    margin:auto;
    padding:o 15px;
}

.header_style
{
    
    padding: 0.5cm;
    margin-top:0 auto 0 auto;
    width:80%;
    height: 10%;
    border:4px  rgb(255, 0, 170) solid;
    border-radius: 1rem;
    text-align:center;
    margin-left:100px;
    color: white;
}

}
header.topbar .container
{
    display: flex;
    justify-content: space-between;
    align-items: center;
}

header.topbar .container  .auth
{
    display: flex;
}

.flex
{
    display: flex;
}
.justify
{
    
    justify-content: space-between;
}
.centre
{
    align-items: center;
}
.justify-centre
{
    justify-content: center;    
}

nav .navbar a
{
    text-decoration: none;
    color: white;
    font-size: 1rem;
    font:bold;
    padding: 1rem 1rem;
}
nav .navbar a.active
{
    background:  rgb(68, 0, 53);
}
nav .navbar a:hover
{
    background:orange;
}

.shadow
{
    position: relative;
    background:rgb(255, 18, 164);
}
#footer
{
padding:10px;
text-align:center;
background-color: rgb(16, 0, 20);
border: 2px  rgb(248, 103, 159) solid;

#footer
#{
#padding:20px;
#border:2px blue solid;
#border-radius:10px;
#text-align:center;
#background-color:black;
#background-color:rgb(18,41,111);
#}
</style>
</head>
</html>

