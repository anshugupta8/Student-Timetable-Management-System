<?php
include("meta.php");
#include("department.css");
?>
<body>
<div class="header-text">
<h1>Student Timetable Management System</h1>
</div>
  <nav>   
            <div class="navbar shadow">
                <div class="container flex justify-centre">
                    <a href="adminhome.php" class=active"><b>Dashboard</b></a>
                    <a href="department.php" ><b>Departments</b></a>
                    <a href="student.html"><b>Students</b></a>
                    <a href="index.php"><b>Log Out</b></a>
                </div>
            </div>
        </nav>




