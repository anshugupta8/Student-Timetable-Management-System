<body>
<div class="header-text">
<h1>Student Timetable Management System</h1>
</div>
